
#ifndef SPOTNG_EXPORT_H
#define SPOTNG_EXPORT_H

#ifdef SPOTNG_STATIC_DEFINE
#  define SPOTNG_EXPORT
#  define SPOTNG_NO_EXPORT
#else
#  ifndef SPOTNG_EXPORT
#    ifdef spotng_EXPORTS
        /* We are building this library */
#      define SPOTNG_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define SPOTNG_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef SPOTNG_NO_EXPORT
#    define SPOTNG_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef SPOTNG_DEPRECATED
#  define SPOTNG_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef SPOTNG_DEPRECATED_EXPORT
#  define SPOTNG_DEPRECATED_EXPORT SPOTNG_EXPORT SPOTNG_DEPRECATED
#endif

#ifndef SPOTNG_DEPRECATED_NO_EXPORT
#  define SPOTNG_DEPRECATED_NO_EXPORT SPOTNG_NO_EXPORT SPOTNG_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef SPOTNG_NO_DEPRECATED
#    define SPOTNG_NO_DEPRECATED
#  endif
#endif

#endif /* SPOTNG_EXPORT_H */
